function deleteConfirmation() {

        return confirm('Are you sure you want to delete this record?');
}

function printConfirmation() {

        return confirm('Are you sure you want to print this record?');
}

function excelPrintConfirmation(){

        return confirm('Are you sure you want to export in Excel File?');
}  

function pdfPrintConfirmation(){

        return confirm('Are you sure you want to export in PDF File?');
}